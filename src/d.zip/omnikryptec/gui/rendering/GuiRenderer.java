package omnikryptec.gui.rendering;

import omnikryptec.graphics.SpriteBatch;

public class GuiRenderer {

	private SpriteBatch batch;
	
}
