package omnikryptec.gui;

import omnikryptec.resource.texture.Texture;

public class GuiObject {
	
	private Texture texture;
	private float x,y;
	
	
	public GuiObject setX(float x) {
		this.x = x;
		return this;
	}
	
}
