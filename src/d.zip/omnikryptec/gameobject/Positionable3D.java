package omnikryptec.gameobject;

import org.joml.Vector3f;

public interface Positionable3D {

	Vector3f getPosition();
	
}
