package omnikryptec.gameobject;

public interface Transformable3D {
	
	Transform3D getTransform();
	
}
