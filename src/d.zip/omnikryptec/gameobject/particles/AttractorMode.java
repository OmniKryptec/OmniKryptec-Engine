package omnikryptec.gameobject.particles;

public enum AttractorMode {
	KILL_ON_REACH, STOP_FOREVER_ON_REACH, STOP_UNTIL_DISABLED_ON_REACH, STOP_ON_REACH, NOTHING;
}
