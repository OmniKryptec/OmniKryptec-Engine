package omnikryptec.gameobject.particles;

import java.util.LinkedList;

public class ParticleList {
	
	LinkedList<Particle> list = new LinkedList<>();
	boolean wantsUpdateLast=false;
	boolean mt;
}
