package omnikryptec.gameobject;

public interface Transformable2D {
	
	Transform2D getTransform();
	
}
