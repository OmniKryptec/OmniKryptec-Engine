package omnikryptec.gameobject;

import org.joml.Vector2f;

public interface Positionable2D {
	
	Vector2f getPosition();
}
