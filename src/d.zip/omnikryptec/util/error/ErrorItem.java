package omnikryptec.util.error;

public interface ErrorItem {
 
	String getError();
	
}
