package omnikryptec.util.action;

/**
 * Action
 *
 * @author Panzer1119
 */
public interface Action {

    public void doAction();

}
