package omnikryptec.util.exceptions;

/**
 *
 * @author Panzer1119
 */
public class UnsupportedCharacterException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -493126597894968110L;

	public UnsupportedCharacterException(String string) {
		super(string);
	}

}
