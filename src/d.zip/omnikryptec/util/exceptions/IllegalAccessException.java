package omnikryptec.util.exceptions;

public class IllegalAccessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7923545731537534232L;

	public IllegalAccessException(String string) {
		super(string);
	}

}
