package omnikryptec.util.exceptions;

public class OmniKryptecException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6447567737530626905L;

	public OmniKryptecException(String s) {
		super(s);
	}

}
