package omnikryptec.util.profiler;

public interface Profilable {
	
	ProfileContainer[] getProfiles();
	
}
