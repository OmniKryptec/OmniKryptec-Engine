package omnikryptec.postprocessing.main;

public interface FBOFactory {

	FrameBufferObject[] getAllFBOs();

}
