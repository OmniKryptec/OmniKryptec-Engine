package omnikryptec.audio;

/**
 * AudioEffectState
 * @author Panzer1119
 */
//test
public enum AudioEffectState {
    NOTHING,
    FADE_IN,
    FADE_OUT;
}
