package omnikryptec.resource.loader;

/**
 * ResourceObject
 *
 * @author Panzer1119 &amp; pcfreak9000
 */
public interface ResourceObject {

    String getName();

    ResourceObject delete();

}
