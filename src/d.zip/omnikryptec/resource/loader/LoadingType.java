package omnikryptec.resource.loader;

/**
 * LoadingType
 *
 * @author Panzer1119
 */
public enum LoadingType {
    NOT,
    NORMAL,
    OPENGL;
}
