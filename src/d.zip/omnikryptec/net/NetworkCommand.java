package omnikryptec.net;

import java.io.Serializable;

/**
 * NetworkCommand
 * @author Panzer1119
 */
public enum NetworkCommand implements Serializable {
    PING,
    PONG;
}
